<p align="center">
  <img src="http://i0.wp.com/www.blog.labouardy.com/wp-content/uploads/2017/08/vpc_tf-1.png?w=462"/>
</p>

How to use in action is shown below:

[![asciicast](https://asciinema.org/a/134951.png)](https://asciinema.org/a/134951)
