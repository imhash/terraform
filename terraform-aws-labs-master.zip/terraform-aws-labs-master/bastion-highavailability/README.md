<p align="center">
  <img src="http://i1.wp.com/www.blog.labouardy.com/wp-content/uploads/2017/10/bastion-1.png?w=741"/>
</p>
