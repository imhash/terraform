<p align="center">
  <img src="http://i2.wp.com/www.blog.labouardy.com/wp-content/uploads/2017/08/etcd_cluster.png?w=462"/>
</p>

How to setup an etcd cluster on AWS is shown below:

[![asciicast](https://asciinema.org/a/135407.png)](https://asciinema.org/a/135407)
